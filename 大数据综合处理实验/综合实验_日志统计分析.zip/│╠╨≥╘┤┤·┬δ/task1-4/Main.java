
public class Main {
    public static void main(String[] args) {
        String input = args[0];
        String output1 = args[1];
        String output2 = args[2];
        String output3 = args[3];
        String output4 = args[4];

        Task1.task1(input, output1);
        Task2.task2(input, output2);
        Task3.task3(input, output3);
        Task4.task4(input, output4);
    }
}
