#ifndef SEMANTIC_H
#define SEMANTIC_H

#include "symTable.h"
#include "syntaxTree.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

void Program(Node *root);

#endif